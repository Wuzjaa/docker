<?php
$c=curl_init("http://localhost:12345");
curl_exec($c);
?>
